package org.finalproject.items.useables.pickupable;

public interface PickupBehavior {
    void pickup();
}
