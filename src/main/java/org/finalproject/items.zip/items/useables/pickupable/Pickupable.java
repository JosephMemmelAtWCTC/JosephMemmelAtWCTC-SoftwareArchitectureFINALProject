package org.finalproject.items.useables.pickupable;


import org.finalproject.items.useables.Useable;

public abstract class Pickupable extends Useable {
}
