package org.finalproject.items.useables.pickupable.consumeable;

import org.finalproject.items.Item;

public abstract class Consumeable extends Pick {

}
