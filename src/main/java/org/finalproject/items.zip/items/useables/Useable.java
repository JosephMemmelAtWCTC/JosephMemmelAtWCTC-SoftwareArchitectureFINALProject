package org.finalproject.items.useables;

import org.finalproject.items.Item;

public abstract class Useable extends Item {
}
