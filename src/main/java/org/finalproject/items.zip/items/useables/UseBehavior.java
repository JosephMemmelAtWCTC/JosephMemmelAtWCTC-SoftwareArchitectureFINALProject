package org.finalproject.items.useables;

public interface UseBehavior {
    void use();
}
