package org.finalproject.items.useables.pickupable.consumeable;

public interface ConsumeBehavior {
    void consume();
}
