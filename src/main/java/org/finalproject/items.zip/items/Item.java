package org.finalproject.items;


public abstract class Item {

	/**
	 * Instance variables of interface type Each duck has a reference to
	 * something that implements the behaviors via an interface. Hey, isn't this
	 * composition the DIP way!!! Only problem is we still have the limitation
	 * that all Ducks have fly and quack behaviors, even thought that is not
	 * always needed.
	 */
//	protected PickupBehavior pickupBehavior;
//	protected UseBehavior useBehavior;

	short quantity;//TODO: Check if this is the correct permission
	String description;//TODO: Check if this is the correct permission

	public Item(){

	}

//	public abstract void display();


//Users
//
//	public void pickupItem() {
//		pickupBehavior.pickup();
//	}
//	public void useItem(){
//		useBehavior.use();
//	}
//
////Setters
//
//	public void setPickupBehavior(PickupBehavior pb){
//		pickupBehavior = pb;
//	}
//
//	public void setUseBehavior(UseBehavior ub){
//		useBehavior = ub;
//	}

	public void setDescription(String description){
		this.description = description;
	}

//Getters
	public void getQuantity() {
	}
	public String getDescription() {
		return description;
	}

}
